/**
 * Centralized API Key Manager
 *
 * This module provides functionality for:
 * - Centralized API key management (admin-only)
 * - Tenant-based API usage tracking
 * - API key rotation and fallbacks
 * - Usage quotas per tenant
 */

(function() {
  console.log('Centralized API Key Manager loaded');

  // Create global API key manager
  window.apiKeyManager = {
    // Central API keys (managed by admin)
    centralKeys: {
      openrouter: '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',  // OpenRouter API key
      openrouter_alt: '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', // Alternative OpenRouter key
      deepseek: 'deepseek v3 free',  // DeepSeek API key
      gemini: 'gemini free',         // Gemini API key
      anthropic: ''                  // Anthropic API key (not provided)
    },

    // Tenant usage tracking
    tenantUsage: {},

    // Current tenant ID
    currentTenantId: null,

    // Subscription tiers and quotas
    subscriptionTiers: {
      free: {
        openrouter: 100,    // 100 requests per month
        openai: 50,         // 50 requests per month
        gemini: 200,        // 200 requests per month
        anthropic: 50       // 50 requests per month
      },
      basic: {
        openrouter: 1000,   // 1,000 requests per month
        openai: 500,        // 500 requests per month
        gemini: 2000,       // 2,000 requests per month
        anthropic: 500      // 500 requests per month
      },
      professional: {
        openrouter: 10000,  // 10,000 requests per month
        openai: 5000,       // 5,000 requests per month
        gemini: 20000,      // 20,000 requests per month
        anthropic: 5000     // 5,000 requests per month
      },
      enterprise: {
        openrouter: -1,     // Unlimited
        openai: -1,         // Unlimited
        gemini: -1,         // Unlimited
        anthropic: -1       // Unlimited
      }
    },

    // Initialize the API key manager
    init: function() {
      console.log('Initializing Centralized API Key Manager');

      // Load tenant usage from localStorage
      this.loadTenantUsage();

      // Set current tenant ID from localStorage or session
      this.currentTenantId = localStorage.getItem('tenantId') || sessionStorage.getItem('tenantId') || 'default';

      console.log('Current tenant ID:', this.currentTenantId);

      // Register event listeners
      document.addEventListener('tenantLogin', this.handleTenantLogin.bind(this));
      document.addEventListener('tenantLogout', this.handleTenantLogout.bind(this));

      // Initialize usage tracking for current tenant
      this.initializeTenantUsage(this.currentTenantId);

      // Load central API keys (in a real implementation, these would be fetched from a secure server)
      this.loadCentralKeys();
    },

    // Load tenant usage from localStorage
    loadTenantUsage: function() {
      try {
        const savedUsage = localStorage.getItem('tenantApiUsage');
        if (savedUsage) {
          this.tenantUsage = JSON.parse(savedUsage);
          console.log('Loaded tenant API usage from localStorage');
        }
      } catch (error) {
        console.error('Error loading tenant API usage:', error);
        this.tenantUsage = {};
      }
    },

    // Save tenant usage to localStorage
    saveTenantUsage: function() {
      try {
        localStorage.setItem('tenantApiUsage', JSON.stringify(this.tenantUsage));
        console.log('Saved tenant API usage to localStorage');
      } catch (error) {
        console.error('Error saving tenant API usage:', error);
      }
    },

    // Load central API keys (in a real implementation, these would be fetched from a secure server)
    loadCentralKeys: function() {
      // In a real implementation, this would make a secure API call to fetch the keys
      // For now, we'll use the hardcoded keys
      console.log('Using hardcoded central API keys (for development only)');

      // In production, you would fetch keys from a secure server
      // Example:
      // fetch('/api/admin/keys', {
      //   method: 'GET',
      //   headers: {
      //     'Authorization': 'Bearer ' + adminToken
      //   }
      // })
      // .then(response => response.json())
      // .then(data => {
      //   this.centralKeys = data.keys;
      // })
      // .catch(error => {
      //   console.error('Error fetching central API keys:', error);
      // });
    },

    // Initialize usage tracking for a tenant
    initializeTenantUsage: function(tenantId) {
      console.log('Initializing API usage tracking for tenant:', tenantId);

      // Create tenant usage tracking if it doesn't exist
      if (!this.tenantUsage[tenantId]) {
        this.tenantUsage[tenantId] = {
          subscription: 'free',  // Default to free tier
          usage: {
            openrouter: 0,
            openai: 0,
            gemini: 0,
            anthropic: 0
          },
          lastUsed: {
            openrouter: null,
            openai: null,
            gemini: null,
            anthropic: null
          },
          resetDate: new Date().toISOString()  // Usage reset date
        };

        this.saveTenantUsage();
      }

      // Check if usage needs to be reset (monthly)
      this.checkUsageReset(tenantId);
    },

    // Check if usage needs to be reset (monthly)
    checkUsageReset: function(tenantId) {
      if (!this.tenantUsage[tenantId]) return;

      const resetDate = new Date(this.tenantUsage[tenantId].resetDate);
      const currentDate = new Date();

      // Reset usage if it's been more than a month
      if (currentDate.getMonth() !== resetDate.getMonth() ||
          currentDate.getFullYear() !== resetDate.getFullYear()) {
        console.log(`Resetting usage for tenant ${tenantId} (monthly reset)`);

        this.tenantUsage[tenantId].usage = {
          openrouter: 0,
          openai: 0,
          gemini: 0,
          anthropic: 0
        };

        this.tenantUsage[tenantId].resetDate = currentDate.toISOString();
        this.saveTenantUsage();
      }
    },

    // Handle tenant login
    handleTenantLogin: function(event) {
      const tenantId = event.detail.tenantId;
      console.log('Tenant login:', tenantId);

      this.currentTenantId = tenantId;
      localStorage.setItem('tenantId', tenantId);

      // Initialize usage tracking
      this.initializeTenantUsage(tenantId);
    },

    // Handle tenant logout
    handleTenantLogout: function() {
      console.log('Tenant logout');

      this.currentTenantId = 'default';
      localStorage.removeItem('tenantId');
    },

    // Get API key for a specific service
    getApiKey: function(service) {
      // Always use the central API key
      const key = this.centralKeys[service];

      // Track usage for the current tenant
      this.trackUsage(service);

      return key;
    },

    // Track API usage for the current tenant
    trackUsage: function(service) {
      const tenantId = this.currentTenantId || 'default';

      // Initialize tenant usage if it doesn't exist
      if (!this.tenantUsage[tenantId]) {
        this.initializeTenantUsage(tenantId);
      }

      // Update usage statistics
      this.tenantUsage[tenantId].usage[service] = (this.tenantUsage[tenantId].usage[service] || 0) + 1;
      this.tenantUsage[tenantId].lastUsed[service] = new Date().toISOString();
      this.saveTenantUsage();

      console.log(`API usage tracked for tenant ${tenantId}, service ${service}`);

      // Check if tenant has exceeded their quota
      this.checkQuota(tenantId, service);
    },

    // Check if tenant has exceeded their quota
    checkQuota: function(tenantId, service) {
      if (!this.tenantUsage[tenantId]) return true;

      const subscription = this.tenantUsage[tenantId].subscription;
      const quota = this.subscriptionTiers[subscription][service];
      const usage = this.tenantUsage[tenantId].usage[service];

      // -1 means unlimited
      if (quota === -1) return true;

      // Check if usage exceeds quota
      if (usage > quota) {
        console.warn(`Tenant ${tenantId} has exceeded their ${service} quota (${usage}/${quota})`);

        // In a real implementation, you might want to notify the user or admin
        // For now, we'll just log a warning

        return false;
      }

      return true;
    },

    // Get usage statistics for current tenant
    getUsageStats: function() {
      const tenantId = this.currentTenantId || 'default';

      if (!this.tenantUsage[tenantId]) {
        return {
          subscription: 'free',
          usage: {
            openrouter: 0,
            openai: 0,
            gemini: 0,
            anthropic: 0
          },
          quotas: this.subscriptionTiers.free
        };
      }

      return {
        subscription: this.tenantUsage[tenantId].subscription,
        usage: this.tenantUsage[tenantId].usage,
        quotas: this.subscriptionTiers[this.tenantUsage[tenantId].subscription]
      };
    },

    // Update tenant subscription (admin only)
    updateTenantSubscription: function(tenantId, subscription) {
      console.log(`Updating subscription for tenant ${tenantId} to ${subscription}`);

      // Initialize tenant usage if it doesn't exist
      if (!this.tenantUsage[tenantId]) {
        this.initializeTenantUsage(tenantId);
      }

      // Update subscription
      this.tenantUsage[tenantId].subscription = subscription;
      this.saveTenantUsage();

      return true;
    },

    // Reset usage statistics for a tenant (admin only)
    resetTenantUsage: function(tenantId) {
      console.log(`Resetting usage for tenant ${tenantId}`);

      if (this.tenantUsage[tenantId]) {
        this.tenantUsage[tenantId].usage = {
          openrouter: 0,
          openai: 0,
          gemini: 0,
          anthropic: 0
        };

        this.tenantUsage[tenantId].resetDate = new Date().toISOString();
        this.saveTenantUsage();

        return true;
      }

      return false;
    }
  };

  // Initialize the API key manager
  window.apiKeyManager.init();
})();
