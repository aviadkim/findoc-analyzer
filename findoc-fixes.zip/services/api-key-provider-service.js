/**
 * API Key Provider Service
 * A service that provides API keys for different AI services
 * with fallback and round-robin strategies
 */

const apiKeyManager = require('./api-key-manager');

// Cache for API keys
const keyCache = new Map();
const keyUsage = new Map();

// Default cache expiration (15 minutes)
const DEFAULT_CACHE_EXPIRATION = 15 * 60 * 1000;

/**
 * Get API key for a specific service
 * @param {string} serviceName - The name of the service (e.g., 'openai', 'gemini')
 * @param {Object} options - Additional options
 * @param {string} options.tenantId - The tenant ID for multi-tenant setups
 * @param {string} options.apiKeyOverride - Override the API key (for testing)
 * @param {boolean} options.forceRefresh - Force refresh the cached key
 * @returns {Promise<string>} - The API key
 */
async function getApiKey(serviceName, options = {}) {
  try {
    const { tenantId, apiKeyOverride, forceRefresh = false } = options;
    
    // If API key override is provided, use it
    if (apiKeyOverride) {
      return apiKeyOverride;
    }
    
    // Create cache key
    const cacheKey = tenantId ? `${tenantId}:${serviceName}` : serviceName;
    
    // Check cache if not forcing refresh
    if (!forceRefresh && keyCache.has(cacheKey)) {
      const cachedItem = keyCache.get(cacheKey);
      
      // Check if cached key is still valid
      if (cachedItem.expiration > Date.now()) {
        // Update usage count
        keyUsage.set(cacheKey, (keyUsage.get(cacheKey) || 0) + 1);
        
        return cachedItem.key;
      }
      
      // Remove expired cache item
      keyCache.delete(cacheKey);
    }
    
    // Get API key from manager
    const apiKey = await apiKeyManager.getApiKey(serviceName, { tenantId });
    
    // Store in cache
    keyCache.set(cacheKey, {
      key: apiKey,
      expiration: Date.now() + DEFAULT_CACHE_EXPIRATION,
    });
    
    // Initialize usage count
    keyUsage.set(cacheKey, 1);
    
    return apiKey;
  } catch (error) {
    console.error(`Error getting API key for ${serviceName}: ${error.message}`);
    throw error;
  }
}

/**
 * Get multiple API keys for a service (for round-robin usage)
 * @param {string} serviceName - The name of the service 
 * @param {Object} options - Additional options
 * @param {string} options.tenantId - The tenant ID for multi-tenant setups
 * @param {boolean} options.forceRefresh - Force refresh the cached keys
 * @returns {Promise<string[]>} - Array of API keys
 */
async function getMultipleApiKeys(serviceName, options = {}) {
  try {
    const { tenantId, forceRefresh = false } = options;
    
    // Create cache key for multiple keys
    const cacheKey = tenantId ? `${tenantId}:${serviceName}:multi` : `${serviceName}:multi`;
    
    // Check cache if not forcing refresh
    if (!forceRefresh && keyCache.has(cacheKey)) {
      const cachedItem = keyCache.get(cacheKey);
      
      // Check if cached keys are still valid
      if (cachedItem.expiration > Date.now()) {
        return cachedItem.keys;
      }
      
      // Remove expired cache item
      keyCache.delete(cacheKey);
    }
    
    // Get API keys from manager (try primary and secondary keys)
    const primaryKey = await apiKeyManager.getApiKey(serviceName, { tenantId })
      .catch(() => null);
    
    const secondaryKey = await apiKeyManager.getApiKey(`${serviceName}-secondary`, { tenantId })
      .catch(() => null);
      
    const tertiaryKey = await apiKeyManager.getApiKey(`${serviceName}-tertiary`, { tenantId })
      .catch(() => null);
    
    // Filter out null keys
    const apiKeys = [primaryKey, secondaryKey, tertiaryKey].filter(key => key !== null);
    
    if (apiKeys.length === 0) {
      throw new Error(`No API keys found for ${serviceName}`);
    }
    
    // Store in cache
    keyCache.set(cacheKey, {
      keys: apiKeys,
      expiration: Date.now() + DEFAULT_CACHE_EXPIRATION,
    });
    
    return apiKeys;
  } catch (error) {
    console.error(`Error getting multiple API keys for ${serviceName}: ${error.message}`);
    throw error;
  }
}

/**
 * Get a round-robin API key
 * @param {string} serviceName - The name of the service
 * @param {Object} options - Additional options
 * @param {string} options.tenantId - The tenant ID for multi-tenant setups
 * @returns {Promise<string>} - The next API key in the rotation
 */
async function getRoundRobinApiKey(serviceName, options = {}) {
  try {
    const { tenantId } = options;
    
    // Get all available keys
    const keys = await getMultipleApiKeys(serviceName, options);
    
    if (keys.length === 1) {
      // Only one key available, so return it
      return keys[0];
    }
    
    // Create cache key for round-robin index
    const rrCacheKey = tenantId ? `${tenantId}:${serviceName}:rr` : `${serviceName}:rr`;
    
    // Get current index (or 0 if not set)
    const currentIndex = keyCache.has(rrCacheKey) ? keyCache.get(rrCacheKey).index : 0;
    
    // Calculate next index
    const nextIndex = (currentIndex + 1) % keys.length;
    
    // Store next index
    keyCache.set(rrCacheKey, { index: nextIndex });
    
    return keys[currentIndex];
  } catch (error) {
    console.error(`Error getting round-robin API key for ${serviceName}: ${error.message}`);
    throw error;
  }
}

/**
 * Store an API key
 * @param {string} serviceName - The service name
 * @param {string} apiKey - The API key
 * @param {Object} options - Additional options
 * @param {string} options.tenantId - The tenant ID for multi-tenant setups
 * @returns {Promise<boolean>} - Whether the operation was successful
 */
async function storeApiKey(serviceName, apiKey, options = {}) {
  try {
    const { tenantId } = options;
    
    // Validate the API key
    const isValid = await apiKeyManager.validateApiKey(serviceName, apiKey);
    
    if (!isValid) {
      throw new Error(`Invalid API key format for ${serviceName}`);
    }
    
    // Store the API key
    const success = await apiKeyManager.storeApiKey(serviceName, apiKey, { tenantId });
    
    if (success) {
      // Clear any cached keys
      const cacheKey = tenantId ? `${tenantId}:${serviceName}` : serviceName;
      const multiCacheKey = tenantId ? `${tenantId}:${serviceName}:multi` : `${serviceName}:multi`;
      const rrCacheKey = tenantId ? `${tenantId}:${serviceName}:rr` : `${serviceName}:rr`;
      
      keyCache.delete(cacheKey);
      keyCache.delete(multiCacheKey);
      keyCache.delete(rrCacheKey);
    }
    
    return success;
  } catch (error) {
    console.error(`Error storing API key for ${serviceName}: ${error.message}`);
    throw error;
  }
}

/**
 * Delete an API key
 * @param {string} serviceName - The service name
 * @param {Object} options - Additional options
 * @param {string} options.tenantId - The tenant ID for multi-tenant setups
 * @returns {Promise<boolean>} - Whether the operation was successful
 */
async function deleteApiKey(serviceName, options = {}) {
  try {
    const { tenantId } = options;
    
    // Delete the API key
    const success = await apiKeyManager.deleteApiKey(serviceName, { tenantId });
    
    if (success) {
      // Clear any cached keys
      const cacheKey = tenantId ? `${tenantId}:${serviceName}` : serviceName;
      const multiCacheKey = tenantId ? `${tenantId}:${serviceName}:multi` : `${serviceName}:multi`;
      const rrCacheKey = tenantId ? `${tenantId}:${serviceName}:rr` : `${serviceName}:rr`;
      
      keyCache.delete(cacheKey);
      keyCache.delete(multiCacheKey);
      keyCache.delete(rrCacheKey);
    }
    
    return success;
  } catch (error) {
    console.error(`Error deleting API key for ${serviceName}: ${error.message}`);
    throw error;
  }
}

// Export functions
module.exports = {
  getApiKey,
  getMultipleApiKeys,
  getRoundRobinApiKey,
  storeApiKey,
  deleteApiKey,
};