/**
 * Simple UI Components Injector Middleware
 * Injects UI components script into all HTML responses
 */

function simpleInjectorMiddleware(req, res, next) {
  console.log(`Simple UI injector middleware called for ${req.path}`);

  // Store original send function
  const originalSend = res.send;

  // Override send function
  res.send = function(body) {
    try {
      // Only modify HTML responses
      if (typeof body === 'string' && body.includes('<!DOCTYPE html>')) {
        console.log(`Injecting UI components script into response for ${req.path}`);

        // Inject script before </body>
        const bodyEndPos = body.indexOf('</body>');
        if (bodyEndPos > 0) {
          // Check if we're on the upload page
          const isUploadPage = req.path.includes('/upload');

          let scriptTag = `
<script src="/js/simple-ui-components.js"></script>
<script>
  console.log('UI components script injected');
</script>
`;

          // If we're on the upload page, also inject the process button script
          if (isUploadPage) {
            scriptTag += `
<script src="/js/direct-process-button-injector.js"></script>
<script>
  console.log('Process button injector script injected');
</script>
`;
          }

          // If we're on the document chat page, inject the document chat fix script
          const isDocumentChatPage = req.path.includes('/document-chat');
          if (isDocumentChatPage) {
            scriptTag += `
<script src="/js/document-chat-fix.js"></script>
<script>
  console.log('Document chat fix script injected');
</script>
`;
          }

          body = body.substring(0, bodyEndPos) + scriptTag + body.substring(bodyEndPos);
          console.log(`Successfully injected UI components script into response for ${req.path}`);
        } else {
          console.warn(`Could not find </body> tag in response for ${req.path}`);
        }
      }
    } catch (error) {
      console.error(`Error injecting UI components script: ${error.message}`);
    }

    // Call original send function
    return originalSend.call(this, body);
  };

  // Continue to next middleware
  next();
}

module.exports = simpleInjectorMiddleware;
